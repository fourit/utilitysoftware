<?php  
	$connect=mysqli_connect("localhost","root","nguyenvantu1994","thuthuattienich") or die('loi');
	mysqli_query($connect,"SET NAMES 'utf8'");
	mysqli_set_charset($connect,"UTF8");
?>
