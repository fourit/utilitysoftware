<div class="row" style="padding-top:100px;">
	<div class="container about">
    	<div class="col-sm-12">
        	<p>Nếu các Bạn có thắc mắc về cài đặt phần mềm, lỗi máy tính, link download lỗi thì các Bạn liên hệ cho mình qua: </p>
            <p>facebook: <a target="_blank" href="https://www.facebook.com/nguyenvantu.k10">Nguyễn Văn Tư</a></p>
            <p>Skype: mrfourit</p>
            <p>Mail: taikhoan.drop@gmail.com</p>
        </div>
    </div>
</div>