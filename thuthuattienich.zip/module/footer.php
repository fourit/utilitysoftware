<div class="row list-loaisoft">
	<div class="col-sm-2">
    	Download windows ISO
        <div class="row">
        	<div class="col-sm-12">
            	<ul style="list-style:none">
                	<li><a href="index.php?loaisoft=isowindowsxp">Windows XP</a></li>
                    <li><a href="index.php?loaisoft=isowindows7">Windows 7</a></li>
                    <li><a href="index.php?loaisoft=isowindows8">Windows 8</a></li>
                    <li><a href="index.php?loaisoft=isowindows81">Windows 8.1</a></li>
                    <li><a href="index.php?loaisoft=isowindows10">Windows 10</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="col-sm-2">
    	Download Ghost windows
        <div class="row">
        	<div class="col-sm-12">
            	<ul style="list-style:none">
                	<li><a href="index.php?loaisoft=ghoxp">Windows XP</a></li>
                    <li><a href="index.php?loaisoft=gho7">Windows 7</a></li>
                    <li><a href="index.php?loaisoft=gho8">Windows 8</a></li>
                    <li><a href="index.php?loaisoft=gho81">Windows 8.1</a></li>
                    <li><a href="index.php?loaisoft=gho10">Windows 10</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-sm-2">
    	Download phần mềm
        <div class="row">
        	<div class="col-sm-12">
            	<ul style="list-style:none">
                	<li><a href="index.php?loaisoft=office">MS Office</a></li>
                    <li><a href="index.php?loaisoft=driver">Download Driver</a></li>
                    <li><a href="index.php?loaisoft=optimazation">Tối ưu hóa</a></li>
                    <li><a href="index.php?loaisoft=antivirus">Phần mềm diệt virus</a></li>
                    <li><a href="index.php?loaisoft=recovery">Khôi phục dữ liệu</a></li>
                </ul>
            </div>
        </div>
    </div>
  <div class="col-sm-6 about">
    	<p>About</p>
        <div class="row">
        	<div class="col-sm-12">
            	<p>Website mong muốn đưa đến cho các Bạn các phần mềm link download ổn định, tốc độ cao. Có hướng dẫn cho các Bạn mới bắt đầu cài đặt phần mềm. Có hỗ trợ teamviewer, support facebook.....</p>
            </div>
        </div>
    </div>
</div>
<div class="row" style="text-align:center;color:#FFF;padding-top:30px">
	<div class="col-sm-12">
    	Copyright &copy; Mr. FourIT 2016. All rights reserved
    </div>
</div>